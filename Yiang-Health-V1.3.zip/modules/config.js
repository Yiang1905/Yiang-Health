/**
 * Yiang Health V1.3 — configuration
 * 1) Create Stripe Payment Links for $9.90 and $29
 * 2) Paste URLs below
 * 3) After each payment, give customer an access code (or set master for testing)
 * 4) Optional: WeChat/Alipay QR image paths under assets/qr/
 */
const YiangConfig = {
  version: '1.3',
  productName: 'Yiang Health',
  positioning: 'China TCM · Wellness · Culture journey planning for global visitors',

  pricing: {
    free: { id: 'explorer', priceUsd: 0, label: 'Explorer' },
    essentials: {
      id: 'essentials',
      priceUsd: 9.9,
      // Stripe Payment Link (public URL only — never secret keys)
      paymentUrl: '',
      // Optional QR image for mobile scan (WeChat/Alipay/Stripe QR you upload)
      qrImage: 'assets/qr/essentials.png'
    },
    full: {
      id: 'full-journey',
      priceUsd: 29,
      paymentUrl: '',
      qrImage: 'assets/qr/full.png'
    }
  },

  /**
   * Access codes you issue after payment (change often).
   * master unlocks everything for your own testing.
   */
  accessCodes: {
    essentials: 'YH-ESSENTIALS-2026',
    full: 'YH-FULL-2026',
    master: 'YH-MASTER-DEMO'
  },

  contactEmail: '',
  policyNote: 'Planning intermediary only. Not a medical provider.'
};

window.YiangConfig = YiangConfig;
